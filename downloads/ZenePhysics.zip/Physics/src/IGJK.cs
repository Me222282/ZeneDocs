﻿namespace Zene.Physics
{
    public interface IGJK
    {

    }
}
