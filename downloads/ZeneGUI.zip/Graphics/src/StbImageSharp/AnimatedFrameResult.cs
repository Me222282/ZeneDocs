﻿namespace StbImageSharp
{
	internal class AnimatedFrameResult : ImageResult
	{
		public int DelayInMs
		{
			get; set;
		}
	}
}