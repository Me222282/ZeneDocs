# The Zene Windowing Library

Temp

## Credits

GLFW Loader also by Zackary Snow(smack0007) - [Source Page](https://github.com/smack0007/GLFWDotNet)</br>