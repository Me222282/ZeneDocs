﻿namespace Zene.Windowing
{
	public struct GammaRamp
	{
		public ushort[] Red { get; set; }
		public ushort[] Green { get; set; }
		public ushort[] Blue { get; set; }
		public uint Size { get; set; }
	}
}
