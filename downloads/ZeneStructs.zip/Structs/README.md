# The Zene Structs Library

The Zene Structs Library is a collection of c# structs that represent/manage geographical objects and values. It is the base for the rest of The Zene Library.

## Credits

Rgb and Hsl converter from [This site](http://csharphelper.com/blog/2016/08/convert-between-rgb-and-hls-color-models-in-c/)</br>

Matrix functions from [OpenTK](https://github.com/opentk/opentk)</br>